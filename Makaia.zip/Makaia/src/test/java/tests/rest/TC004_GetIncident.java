package tests.rest;

import java.io.File;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.rest.RESTAssuredBase;


public class TC004_GetIncident extends RESTAssuredBase{
//For Reporting 
	@BeforeTest// - > 2
	public void setValues() {

		testCaseName = "Get an Incident (REST)";
		testDescription = "Get an Incident and Verify";
		nodes = "Incident";
		authors = "Sarath";
		category = "REST";
		dataFileName = "TC001";
		dataFileType = "JSON";
	}

	@Test(dataProvider = "fetchData")
	public void getIncident(File file) {		
		
		// get the request
		Response response = get("table/incident","sys_id","9c573169c611228700193229fff72400");
		
		//Verify the Content by Specific Key
		verifyContentsWithKey(response, "result.short_description", "Can't read email");
		
		// Verify the Content type
		verifyContentType(response, "JSON");
		
		// Verify the response status code
		verifyResponseCode(response, 200);	
		
		// Verify the response time
		verifyResponseTime(response, 10000);
		
	}


}





